package com.antisocial.app.webapi.domain;

/**
 * Created by Igibek on 4/24/2015.
 */
public class UserDataResponse {
    private int Score;
    private int TotalBlockedTime;

    public void setScore(int score) {
        Score = score;
    }

    public void setTotalBlockedTime(int totalBlockedTime) {
        TotalBlockedTime = totalBlockedTime;
    }

    public int getScore() {
        return Score;
    }

    public int getTotalBlockedTime() {
        return TotalBlockedTime;
    }
}
