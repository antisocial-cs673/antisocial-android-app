package com.antisocial.app.webapi.communication.requests;

/**
 * Created by Abdikalykov on 3/14/2015.
 */
public class PostLogoutRequest {
}
