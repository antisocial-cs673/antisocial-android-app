package com.dg.libs.rest.client;

public enum RequestMethod {
  GET, POST, PUT, PATCH, DELETE;
}
